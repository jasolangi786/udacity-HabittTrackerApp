package com.example.hpelitebook810.habitttrackerapp.data;

import android.provider.BaseColumns;

/**
 * Created by Hp EliTEbooK 810 on 11/9/2016.
 */
public class PrayerContract {

    private PrayerContract(){

        }
    public static class PrayerEntry implements BaseColumns{

        public static final String TABLE_NAME = "prayers";

        public static final String _ID = BaseColumns._ID;
        public static final String COLUMN_PRAYER_TIME = "PrayerTime";
        public static final String COLUMN_PRAYER_DESCRIPTION = "PrayerDescription";

    }
}
