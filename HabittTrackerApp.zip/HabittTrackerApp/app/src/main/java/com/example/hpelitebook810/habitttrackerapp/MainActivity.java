package com.example.hpelitebook810.habitttrackerapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.example.hpelitebook810.habitttrackerapp.data.PrayerContract.PrayerEntry;
import com.example.hpelitebook810.habitttrackerapp.data.PrayerDbHelper;

public class MainActivity extends AppCompatActivity {

    SQLiteDatabase pdb;
    private PrayerDbHelper mDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        insertPrayer();
    }

    private void insertPrayer() {
        mDbHelper = new PrayerDbHelper(this);
        pdb = mDbHelper.getWritableDatabase();

        ContentValues prayers = new ContentValues();
        prayers.put(PrayerEntry.COLUMN_PRAYER_TIME, 1200);
        prayers.put(PrayerEntry.COLUMN_PRAYER_DESCRIPTION, "Afternoon Prayer");

        long newId = pdb.insert(PrayerEntry.TABLE_NAME, null, prayers);
        Log.v("MainActivity", "newId: " + newId);
    }

    private Cursor readPrayer() {
        mDbHelper = new PrayerDbHelper(this);
        pdb = mDbHelper.getWritableDatabase();

        String[] projection = {
                PrayerEntry._ID,
                PrayerEntry.COLUMN_PRAYER_TIME,
                PrayerEntry.COLUMN_PRAYER_DESCRIPTION
        };

        Cursor cursor = pdb.query(
                PrayerEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );
        return cursor;
    }
}