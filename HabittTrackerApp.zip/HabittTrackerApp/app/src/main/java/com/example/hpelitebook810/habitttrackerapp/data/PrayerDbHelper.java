package com.example.hpelitebook810.habitttrackerapp.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class PrayerDbHelper extends SQLiteOpenHelper {

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "PrayerTracker.db";

    public PrayerDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public void onCreate(SQLiteDatabase pdb) {
        String SQL_CREATE_ENTRIES = "CREATE TABLE " + PrayerContract.PrayerEntry.TABLE_NAME + "("
                + PrayerContract.PrayerEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                PrayerContract.PrayerEntry.COLUMN_PRAYER_TIME + " INTEGER NOT NULL, " +
                PrayerContract.PrayerEntry.COLUMN_PRAYER_DESCRIPTION + " TEXT)";
        pdb.execSQL(SQL_CREATE_ENTRIES);
    }

    public void onUpgrade(SQLiteDatabase pdb, int oldVersion, int newVersion) {

    }
}